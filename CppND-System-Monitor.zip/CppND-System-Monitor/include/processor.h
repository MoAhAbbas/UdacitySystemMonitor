#ifndef PROCESSOR_H
#define PROCESSOR_H

class Processor {
 public:
  float Utilization();  // TODO: See src/processor.cpp
  long Current_TotalJeffie();
  long Current_ActiveJeffie();
  long Current_IdleJeffie();

  long Pre_TotalJeffie();
  long Pre_IdleJeffie();
  long Pre_ActiveJeffie();
  void UpdateJeffie(long active, long idle, long total);
  // TODO: Declare any necessary private members
 private:
 long t_Idle;
  long t_Active;
  long t_Total;
};

#endif