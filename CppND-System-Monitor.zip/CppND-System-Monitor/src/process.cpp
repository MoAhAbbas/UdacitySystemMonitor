#include <unistd.h>
#include <cctype>
#include <sstream>
#include <string>
#include <vector>
#include "linux_parser.h"
#include "process.h"

using std::string;
using std::to_string;
using std::vector;
Process::Process(int pid) {
  t_PID = pid;
  t_CMD = LinuxParser::Command(pid);
  std::string t_RAM = LinuxParser::Ram(pid);
  t_UpTime = LinuxParser::UpTime(pid);
  t_User = LinuxParser::User(pid);

  long Seconds = LinuxParser::UpTime() - t_UpTime;
  long TotalTime = LinuxParser::ActiveJiffies(pid);
  try {
    t_UtiliZation = float(TotalTime) / float(Seconds);

  } catch (...) {
    t_UtiliZation = 0;
  }
}
// TODO: Return this process's ID
int Process::Pid() { return t_PID; }

// TODO: Return this process's CPU utilization
float Process::CpuUtilization() { return t_UtiliZation; }

// TODO: Return the command that generated this process
string Process::Command() { return t_CMD; }

// TODO: Return this process's memory utilization
string Process::Ram() { return t_RAM ;}

// TODO: Return the user (name) that generated this process
string Process::User() { return t_User; }

// TODO: Return the age of this process (in seconds)
long int Process::UpTime() { return t_UpTime; }

// TODO: Overload the "less than" comparison operator for Process objects
// REMOVE: [[maybe_unused]] once you define the function
bool Process::operator<(Process & a )  { 
    return   CpuUtilization() < a.CpuUtilization(); 
    }