#include "processor.h"
#include "linux_parser.h"
// TODO: Return the aggregate CPU utilization
float Processor::Utilization() { 
long old_totalJeffie, new_TotalJeffie, new_ActiveJeffie, old_IdleJeffie, new_IdleJeffie;
  new_TotalJeffie = Current_TotalJeffie();
  new_ActiveJeffie = Current_ActiveJeffie();
  new_IdleJeffie = Current_IdleJeffie();

  old_totalJeffie = Pre_TotalJeffie();
  old_IdleJeffie = Pre_IdleJeffie();

  UpdateJeffie(new_ActiveJeffie, new_IdleJeffie, new_TotalJeffie);

  float TotalDiff = float(new_TotalJeffie) - float(old_totalJeffie);
  float IdleDiff = float(new_IdleJeffie) - float(old_IdleJeffie);

  float utilization = (TotalDiff - IdleDiff) / TotalDiff;

  return utilization;
}

long Processor::Current_TotalJeffie() { return LinuxParser::Jiffies(); }
long Processor::Current_ActiveJeffie() { return LinuxParser::ActiveJiffies(); }
long Processor::Current_IdleJeffie() { return LinuxParser::IdleJiffies(); }

long Processor::Pre_TotalJeffie() { return t_Total; }
long Processor::Pre_ActiveJeffie() { return t_Active; }
long Processor::Pre_IdleJeffie() { return t_Idle; }
void Processor::UpdateJeffie( long active,long idle, long total) {
  t_Idle = idle;
  t_Active = active;
  t_Total = total;
}


 