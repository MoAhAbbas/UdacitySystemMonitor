#include <dirent.h>
#include <unistd.h>
#include <string>
#include <vector>

#include "linux_parser.h"

using std::stof;
using std::string;
using std::to_string;
using std::vector;

// DONE: An example of how to read data from the filesystem
string LinuxParser::OperatingSystem() {
  string line;
  string key;
  string value;
  std::ifstream filestream(kOSPath);
  if (filestream.is_open()) {
    while (std::getline(filestream, line)) {
      std::replace(line.begin(), line.end(), ' ', '_');
      std::replace(line.begin(), line.end(), '=', ' ');
      std::replace(line.begin(), line.end(), '"', ' ');
      std::istringstream linestream(line);
      while (linestream >> key >> value) {
        if (key == "PRETTY_NAME") {
          std::replace(value.begin(), value.end(), '_', ' ');
          return value;
        }
      }
    }
  }
  return value;
}

// DONE: An example of how to read data from the filesystem
string LinuxParser::Kernel() {
  string os, version, kernel;
  string line;
  std::ifstream stream(kProcDirectory + kVersionFilename);
  if (stream.is_open()) {
    std::getline(stream, line);
    std::istringstream linestream(line);
    linestream >> os >> version >> kernel;
  }
  return kernel;
}

// BONUS: Update this to use std::filesystem
vector<int> LinuxParser::Pids() {
  vector<int> pids;
  DIR* directory = opendir(kProcDirectory.c_str());
  struct dirent* file;
  while ((file = readdir(directory)) != nullptr) {
    // Is this a directory?
    if (file->d_type == DT_DIR) {
      // Is every character of the name a digit?
      string filename(file->d_name);
      if (std::all_of(filename.begin(), filename.end(), isdigit)) {
        int pid = stoi(filename);
        pids.push_back(pid);
      }
    }
  }
  closedir(directory);
  return pids;
}

// TODO: Read and return the system memory utilization
float LinuxParser::MemoryUtilization() { 

// Declare Two String Variable to Store the Key and Line to parse
  string line, key;
  // Declare two floating Variable to Store Memory Usage (Free ,total)
  float totalMem = 1, freeMem = 1;
  // Read the path of memory utilization
  std::ifstream stream(kProcDirectory + kMeminfoFilename);
  //open the File
  if (stream.is_open()) {
    //Loop through each Line
    while (std::getline(stream, line)) {
      //using String Stream Library
      std::istringstream linestream(line);
// Read the Key
      linestream >> key;
     //Check if total memory Attribute is parsed
      if (key == "MemTotal:") {
        //Read the Total memory and Store it in TotalMem Variable
        linestream >> totalMem;
        //Check if  memory Available Attribute is parsed
      } else if (key == "MemAvailable:") {
        //Read the  memory Available and Store it in FreeMem Variable
        linestream >> freeMem;
        break;
      }
    }
  }
  //Calculate the usage memory by subtracting total used , free memory
float memUsed = (totalMem - freeMem);
//Calculate and return the percentage of memory used
  return (memUsed) / totalMem;}

// TODO: Read and return the system uptime
long LinuxParser::UpTime() { 

// Declate Two String to Parse the File
  string line, uptimeStr;
  //Parse Up Time File 
  std::ifstream stream(kProcDirectory + kUptimeFilename);
  //Open the File 
  if (stream.is_open()) {
    //read the Line
    std::getline(stream, line);
    //Stream the Line Read
    std::istringstream uptimeStream(line);
    //Parse the Up time Parameter
    uptimeStream >> uptimeStr;
  }
   //Return Up Time 
    return std::stol(uptimeStr);
 }

// TODO: Read and return the number of jiffies for the system
long LinuxParser::Jiffies() { 

  return LinuxParser::ActiveJiffies() + LinuxParser::IdleJiffies();
 }

// TODO: Read and return the number of active jiffies for a PID
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::ActiveJiffies(int pid[[maybe_unused]]) {
 //Declare Local variable to Hold the Total time of Active Jiffie
   long totaltime;
   // Declare Two String Variable to Store the Values and Line to parse
  string line, value;
   // Declare Vector of Strings to Hold the Values parsed
  vector<string> values;
   // parse the Path for Passed PID
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatFilename);
   //Open the File 
  if (stream.is_open()) {
     //Parse the Line
    std::getline(stream, line);
     //Stream the Line
    std::istringstream linestream(line);
    //Looping through all values and Store it the created Vector
    while (linestream >> value) {
      values.push_back(value);
    }
  }

 // Get the Numbers from Strings parsed and make sure of correct parsing
  long utime = 0, stime = 0 , cutime = 0, cstime = 0;
  
  if (std::all_of(values[16].begin(), values[16].end(), isdigit))
    cstime = stol(values[16]);
  if (std::all_of(values[15].begin(), values[15].end(), isdigit))
    cutime = stol(values[15]);
     if (std::all_of(values[14].begin(), values[14].end(), isdigit))
    stime = stol(values[14]);
    if (std::all_of(values[13].begin(), values[13].end(), isdigit))
    utime = stol(values[13]);
 // Calculate all Time Parsed
  totaltime = utime + stime + cutime + cstime;
   // Get thee Time of Active jiffies by dividing it by System clock
  return totaltime / sysconf(_SC_CLK_TCK);
 }

// TODO: Read and return the number of active jiffies for the system
long LinuxParser::ActiveJiffies() { 
 // Create Local variable hold Infor about CPU Utilization
auto Jiffies = CpuUtilization();
  // sum all Numbers of Jiffies Attributes as following
long totlaCPUutil=stol(Jiffies[CPUStates::kUser_])+ 
         stol(Jiffies[CPUStates::kIRQ_]) + 
         stol(Jiffies[CPUStates::kNice_]) +
         stol(Jiffies[CPUStates::kSteal_])+
         stol(Jiffies[CPUStates::kSystem_]) + 
         stol(Jiffies[CPUStates::kSoftIRQ_]) ;
          // return total sum calculated
  return totlaCPUutil;
 }

// TODO: Read and return the number of idle jiffies for the system
long LinuxParser::IdleJiffies() { 

// Create Local variable hold Infor about CPU Utilization
auto Jiffies = CpuUtilization();

  // sum all Numbers of Jiffies Attributes as following
long totlaCPUutil=stol(Jiffies[CPUStates::kIdle_]) +
                  stol(Jiffies[CPUStates::kIOwait_]);
          // return total sum calculated
  return totlaCPUutil;

}

// TODO: Read and return CPU utilization
vector<string> LinuxParser::CpuUtilization() { 

  // Declare 3 Temp variables to hold Line Parsed and CPU and Numbered Value 
 string line, cpu, Numberedvalue;
 // Create Vector to hold jiffies
  vector<string> jiffies;
  //Parse the Path of CPU Statistics
  std::ifstream stream(kProcDirectory + kStatFilename);
  //Open the File
  if (stream.is_open()) {
    //read the Line form Stat file 
    std::getline(stream, line);
    //Stream the Line
    std::istringstream linestream(line);
//read CPU
    linestream >> cpu;
// Iterate through the Lines to Get all Statistics Numbers
    while (linestream >> Numberedvalue) {
      // Push it in the Vector Jiffies
      jiffies.push_back(Numberedvalue);
    }
  }
  //Return Jiffies
  return jiffies;
 }

// TODO: Read and return the total number of processes
int LinuxParser::TotalProcesses() { 

// Create Temp Local variable to hold the total number of processes
 int Totalprocesses;
 // Declare String variable for Parsing Stat file
string line, key;
//Parse the file Path
  std::ifstream stream(kProcDirectory + kStatFilename);
  //Open the file 
  if (stream.is_open()) {
    // Iteratinh through the File till Reaching the Key
    while (std::getline(stream, line)) {
      //Stream the Line parsed
      std::istringstream linestream(line);
      //Read the Key
      linestream >> key;
      //Check if the Key is the Processed Attribute
      if (key == "processes") {
        //If though Read and Store it in Local created Variable Totalprocesses 
        linestream >>Totalprocesses;
        break;
      }
    }
  }
  // return the Variable
  return Totalprocesses;
 }

// TODO: Read and return the number of running processes
int LinuxParser::RunningProcesses() {   
  
  // Create Temp Local variable to hold the total number of running processes
 int Runningprocesses;
 // Declare String variable for Parsing Stat file
string line, key;
//Parse the file Path
  std::ifstream stream(kProcDirectory + kStatFilename);
  //Open the file 
  if (stream.is_open()) {
    // Iteratinh through the File till Reaching the Key
    while (std::getline(stream, line)) {
      //Stream the Line parsed
      std::istringstream linestream(line);
      //Read the Key
      linestream >> key;
      //Check if the Key is the procs_running Attribute
      if (key == "procs_running") {
        //If though Read and Store it in Local created Variable Runningprocesses 
        linestream >>Runningprocesses;
        break;
      }
    }
  }
  // return the Variable
  return Runningprocesses;
 }

// TODO: Read and return the command associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Command(int pid) { 

 // Create command Variable String  
string CMD;
// Parse the Path of Commands file + Pid+ Directorty
  std::ifstream stream(kProcDirectory + to_string(pid) + kCmdlineFilename);
  //Open the File
  if (stream.is_open()) {
    //Read the command Line
    std::getline(stream, CMD);
  }
  //Return the Command
  return CMD;
 }

// TODO: Read and return the memory used by a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Ram(int pid) {
// Create String Variables to Hold the Parsed Parameters
string line, key, memStr;
// Create Temp Local Variable to Hold
  long Vmem;
// Parse the Path for Ram Statistics
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatusFilename);
  // Open the File 
  if (stream.is_open()) {
    //Iterate through all Lines
    while (std::getline(stream, line)) {
      //Stream the Lines
      std::istringstream linestream(line);
      //read the Key
      linestream >> key;
      //check if the Key Parsed is Vmsize
      if (key == "VmSize:") {
        // If though Read the Memory Size
        linestream >> Vmem;
        //Divide it by 1000
        Vmem /= 1000;
        //Convertback to String 
        memStr = std::to_string(Vmem);
        break;
      }
    }
  }
  // Return Memeorysize as string
  return memStr;
   }

// TODO: Read and return the user ID associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::Uid(int pid) { 

 // Create Local Strings for the Parsed Parameter
   string line, key, Uid;
   //Parse the Path of UID
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatusFilename);
  
  //open the File 
  if (stream.is_open()) {
    //Iterate through each line
    while (std::getline(stream, line)) {
      //Stream the Parsed Line
      std::istringstream linestream(line);
      //Read the Key
      linestream >> key;
      //Check if the Key is Uid Attribute
      if (key == "Uid:") {
        //Set the UID String with the Parsed one from file
        linestream >> Uid;
        break;
      }
    }
  }
  //Return UID
  return Uid;
}
// TODO: Read and return the user associated with a process
// REMOVE: [[maybe_unused]] once you define the function
string LinuxParser::User(int pid) { 

// Create Local String Variable hold the UID of Passed pid of User
  string uid = Uid(pid);
//Create Strings local variable to hold different Paramters to be parsed
  string ID, dontcare, temp, line;
  //Create Local String variable to be Returned as user associated process
  string Username = "DEFAULT";
  //Parse the Path 
  std::ifstream stream(kPasswordPath);
  //Open the file 
  if (stream.is_open()) {
    //read the String Line
    while (std::getline(stream, line)) {
      //Remove : Sign for Simlifying Parsing
      std::replace(line.begin(), line.end(), ':', ' ');
      //Stream the Line
      std::istringstream linestream(line);
//Store the parsed paramters into the create Local variables
      linestream >> temp >>dontcare >> ID;
      //check if used ID matched with buffered IDs
      if (ID == uid) {
        //If Though Return the Found used ID
        Username = temp;
        break;
      }
    }
  }
  return Username;

 }

// TODO: Read and return the uptime of a process
// REMOVE: [[maybe_unused]] once you define the function
long LinuxParser::UpTime(int pid) {  
//Create Local String Variables for Parsing the File 
  string line, value;
  //Create Vector to Hold the Numbered Values of Up time of a process
  vector<string> UpTimeValues;
  //Create Local Temp Varibale to Calculate the Start Time 
  long BootTime = 0;
  //Parse the File 
  std::ifstream stream(kProcDirectory + to_string(pid) + kStatFilename);
  //open the File 
  if (stream.is_open()) {
    //read the Line
    std::getline(stream, line);
    //Stream the Line
    std::istringstream linestream(line);
    //Iterate through the Line 
    while (linestream >> value) {
      //fill the Vector with all Values
      UpTimeValues.push_back(value);
    }
  }
 //calaculate the BootTime of the Process
    BootTime = stol(UpTimeValues[21]) / sysconf(_SC_CLK_TCK);

  //Return the Start up Time
  return BootTime; }
